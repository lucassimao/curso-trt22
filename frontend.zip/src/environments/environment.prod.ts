export const environment = {
  production: true,
  backend: "${BACKEND}",
  keycloak_backend: "${KEYCLOACK}",
  client_id: "${KEYCLOACK_CLIENT_ID}"
};
