export interface Usuario {
  nome: string;
  email: string;
  papeis: string[];
  validadeToken: number;
}
