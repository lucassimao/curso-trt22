export interface AccessTokenPayload {
  validade: Date;
  emissao: Date;
  tipo: string;
}
