#!/bin/bash

docker build --build-arg BACKEND=http://localhost:8080 \
--build-arg KEYCLOACK=http://keycloak.trt22.jus.br:8080/auth/realms/trt22/protocol/openid-connect/token \
--build-arg KEYCLOACK_CLIENT_ID=trt22-demo-backend -t trt22-frontend .
