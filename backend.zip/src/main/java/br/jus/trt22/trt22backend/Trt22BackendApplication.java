package br.jus.trt22.trt22backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Trt22BackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(Trt22BackendApplication.class, args);
	}

}
